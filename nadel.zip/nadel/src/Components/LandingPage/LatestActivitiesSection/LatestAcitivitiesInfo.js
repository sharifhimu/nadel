

export const info = [


{   id:1,
    date: '16',
    month: 'OCT',
    mainLocation: 'TSC, Dhaka University',
    fullDate: ' February 6,2021',
    time: '8:00 PM - 10:00 PM',
    fullLocation: 'Fular Road, Dhaka University, Dhaka-1205'
},
{   id:2,
    date: '20',
    month: 'OCT',
    mainLocation: 'RAMNA, Dhaka University',
    fullDate: ' February 6,2021',
    time: '8:00 PM - 10:00 PM',
    fullLocation: 'Fular Road, Dhaka University, Dhaka-1205'
},



]



export const smallVideo = [

    {
        img: 'videoImage1.png',
        id:1,
        title: 'Parliament Session 2019',
        date: '21 September, 2019',
        text: 'It is working It is working It is working It is working ',
        video: `https://www.youtube.com/embed/4w_NdW-Jv5E`

    },
    {
        img: 'videoImage2.png',
        id:2,
        title: 'sylet',
        date: '21 September, 2019',
        text: 'yes yes yes yes yes yes yes yes yes',
        video: `https://www.youtube.com/embed/vOJBdnyK6gI`
    },
    {
        img: 'videoImage1.png',
        id:3,
        title: 'Parliament Session 2019',
        date: '21 September, 2019',
        text: 'jkdashlifhsafiusdfiuasyfdiusfdaiasposadj ksahfshuiui',
        video: `https://www.youtube.com/embed/4w_NdW-Jv5E`
    },
    {
        img: 'videoImage2.png',
        id:4,
        title: 'Parliament Session 2019',
        date: '21 September, 2019',
        text: '123 microphone testing 123 microphone testing 123 microphone testing 123 microphone testing 123 microphone testing ',
        video: `https://www.youtube.com/embed/vOJBdnyK6gI`
    },
]