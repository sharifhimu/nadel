import img1 from '../../assets/image/gallery/img1.png';
import img2 from '../../assets/image/gallery/img2.png';
import img3 from '../../assets/image/gallery/img3.png';
// import img4 from '../../assets/image/gallery/img4.png';


// import link1 from '../../../OnlyPages/GalleryDetailsPage/GalleryDetailsPage';

export const Galleryinfo = [

    {
        img: img1,
        href: `gallerydetails`

        
    },
    {
        img: img2,
        
         
        
    },
    {
        img: img3,
       
         
        
    },
    {
        img: img1,
       
        
    },
    {
        img: img2,
       
    },
    {
        img: img3,
       
        
    },
   
   


]