import img1 from '../../assets/image/newsViews/img1.png';
import img2 from '../../assets/image/newsViews/img2.png';
import img3 from '../../assets/image/newsViews/img3.png';
import img4 from '../../assets/image/newsViews/img4.png';




export const newsinfo = [

    {
        img: img1,
        title: 'Discussion About BCB',
        text: ' Some quick example text to build on the card title and make up the bulk of the card\'s content',
        date: '21 Sep, 2019, 4:42PM'

        
    },
    {
        img: img2,
        title: 'Sports Field Observation',
        text: ' Some quick example text to build on the card title and make up the bulk of the card\'s content',
        date: '21 Sep, 2019, 4:42PM'
         
        
    },
    {
        img: img3,
        title: 'Parliament Session 2019',
        text: ' Some quick example text to build on the card title and make up the bulk of the card\'s content',
        date: '21 Sep, 2019, 4:42PM'
         
        
    },
    {
        img: img4,
        title: 'Director of BCB',
        text: ' Some quick example text to build on the card title and make up the bulk of the card\'s content',
        date: '21 Sep, 2019, 4:42PM'
         
        
    },
    {
        img: img1,
        title: 'Card Title',
        text: ' Some quick example text to build on the card title and make up the bulk of the card\'s content',
        date: '21 Sep, 2019, 4:42PM'
         
        
    }




]