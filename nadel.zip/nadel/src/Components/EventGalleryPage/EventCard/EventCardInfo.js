import one from '../../assets/image/eventGallery/one.png';
import two from '../../assets/image/eventGallery/two.png';
import three from '../../assets/image/eventGallery/three.png';
import four from '../../assets/image/eventGallery/four.png';
import five from '../../assets/image/eventGallery/five.png';
import six from '../../assets/image/eventGallery/six.png';



export const cardinfo = [

    {
        img: one,
        title: 'Sports Field Observation',
        date: '21 January 2020' 
    },
    {
        img: two,
        title: 'Parliament Session 2019',
        date: '21 January 2020' 
    },
    {
        img: three,
        title: 'Online meeting during COVID',
        date: '21 January 2020' 
    },
    {
        img: four,
        title: 'BCB Board Meeting',
        date: '21 January 2020' 
    },
    {
        img: five,
        title: 'Discussion About BCB',
        date: '21 January 2020' 
    },
    {
        img: six,
        title: 'Spring Ceremony Held',
        date: '21 January 2020' 
    },
]