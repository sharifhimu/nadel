
import one from '../../assets/image/gallerydetails/one.png';
import two from '../../assets/image/gallerydetails/two.png';
import three from '../../assets/image/gallerydetails/three.png';
import four from '../../assets/image/gallerydetails/four.png';



export const info = [


    {
       img: one ,
       title: 'BCB Meeting'

    },
    {
        img: two,
        title: 'Board Meeting Dhaka' 
 
     },
     {
        img: three,
        title: 'Board Meeting Dhaka'
 
     },
     {
        img: four,
        title: 'BCB Meeting' 
 
     },
     {
        img: one ,
        title: 'BCB Meeting'
 
     },
     {
         img: two,
         title: 'Board Meeting Dhaka' 
  
      },
      {
         img: three,
         title: 'Board Meeting Dhaka'
  
      },
      {
         img: four,
         title: 'BCB Meeting' 
  
      },
]