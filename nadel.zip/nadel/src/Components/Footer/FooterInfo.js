import img1 from '../assets/image/footer_update/update1.png';
import img2 from '../assets/image/footer_update/update2.png';
import img3 from '../assets/image/footer_update/update3.png';


export const footerInfo = [


{
    img: img1,
    title: 'Future Where Technology Creates Good Source',
    link: `https://medium.com/@cdixon/eleven-reasons-to-be-excited-about-the-future-of-technology-ef5f9b939cb2`
},
{
    img: img2,
    title: 'Future Where Technology Creates Good Source',
    link: `https://medium.com/@cdixon/eleven-reasons-to-be-excited-about-the-future-of-technology-ef5f9b939cb2`
},
{
    img: img3,
    title: 'Future Where Technology Creates Good Source',
    link: `https://medium.com/@cdixon/eleven-reasons-to-be-excited-about-the-future-of-technology-ef5f9b939cb2`
}




]