import one from '../assets/image/newsDetailsPage/mostRead/one.png'
import two from '../assets/image/newsDetailsPage/mostRead/two.png'
import three from '../assets/image/newsDetailsPage/mostRead/three.png'
import four from '../assets/image/newsDetailsPage/mostRead/four.png'

export const newsinfo = [
    {
        img: one,
        title: 'Parliament Session Got Huge Acknowledge'
    },
    {
        img: two,
        title: 'Parliament Session Got Huge Acknowledge'
    },
    {
        img: three,
        title: 'Parliament Session Got Huge Acknowledge'
    },
    {
        img: four,
        title: 'Parliament Session Got Huge Acknowledge'
    }
]

export const recentnewsinfo = [
    {
        title: 'Masrafi bin mortoza Tests Positive For covid 19',
        link: 'https://www.cricbuzz.com/profiles/323/mashrafe-mortaza'
    },
    {
        title: '20 Bangladesh Judges Infected With Covid 19',
        link: 'https://www.cricbuzz.com/profiles/323/mashrafe-mortaza'
    },
    {
        title: 'AL Leader Hanif Flies To Canada To Visit family',
        link: 'https://www.cricbuzz.com/profiles/323/mashrafe-mortaza'
    },
    {
        title: 'Masrafi bin mortoza Tests Positive For covid 19',
        link: 'https://www.cricbuzz.com/profiles/323/mashrafe-mortaza'
    },
    {
        title: 'Masrafi bin mortoza Tests Positive For covid 19',
        link: 'https://www.cricbuzz.com/profiles/323/mashrafe-mortaza'
    },
    {
        title: '20 Bangladesh Judges Infected With Covid 19',
        link: 'https://www.cricbuzz.com/profiles/323/mashrafe-mortaza'
    },
    {
        title: 'AL Leader Hanif Flies To Canada To Visit family',
        link: 'https://www.cricbuzz.com/profiles/323/mashrafe-mortaza'
    },
    {
        title: 'Masrafi bin mortoza Tests Positive For covid 19',
        link: 'https://www.cricbuzz.com/profiles/323/mashrafe-mortaza'
    },
]