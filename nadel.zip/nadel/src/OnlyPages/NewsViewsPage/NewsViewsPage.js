import React from 'react';

import NewsViewsCard from '../../Components/NewsViewsPage/NewsViewsCard/NewsViewsCard';

const NewsViewsPage = () => {
    return (
        <div>
            <NewsViewsCard />
            
        </div>
    );
};

export default NewsViewsPage;