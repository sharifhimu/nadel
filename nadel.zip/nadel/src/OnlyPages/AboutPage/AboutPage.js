import React from 'react';

import About from '../../Components/AboutPage/About';

const AboutPage = () => {
    return (
        <div>
            <About />
        </div>
    );
};

export default AboutPage;