import React from 'react';

import GalleryCard from '../../Components/GalleryDetailsPage/GalleryCard/GalleryCard';

const GalleryDetailsPage = () => {
    return (
        <div>
            <GalleryCard />
        </div>
    );
};

export default GalleryDetailsPage;