import React from 'react';
import NewsPage from '../../Components/NewsDetailsPage/NewsPage';

const NewsDetailsPage = () => {
    return (
        <div>
            <NewsPage />
        </div>
    );
};

export default NewsDetailsPage;