import React from 'react';
import EventCard from '../../Components/EventGalleryPage/EventCard/EventCard';


const EventGalleryPage = () => {
    return (
        <div>
            <EventCard />
           
        </div>
    );
};

export default EventGalleryPage;